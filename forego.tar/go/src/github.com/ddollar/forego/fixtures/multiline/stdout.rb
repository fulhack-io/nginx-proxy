#!/usr/bin/env ruby

$stdout.sync = true

puts "a"
sleep 1
puts "a\nb"
sleep 1
puts "a\nb\nc"
sleep 1
puts "a\nb\nc\nd"
sleep 1
puts "finish!"
